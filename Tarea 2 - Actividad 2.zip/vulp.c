/* vulp.c*/

#include <stdio.h> 
#include <unistd.h>
#include <string.h> 
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

#define DELAY 10000

int main() {

 char * fn = "/tmp/XYZ"; 
 char buffer[60]; 
 FILE *fp; 
 long int i; 

 // Adding vars for i-nodes
 int f1, f2, f3, f4;
 struct stat stat1, stat2, stat3, stat4;

 /* get user input */ 
 scanf("%60s", buffer ); 

/* Previous Code
 if (!access(fn, W_OK)) { 

    // simulating delay 
    for (i = 0; i < DELAY; i++) {
        int a = i^2; 
    } 

    fp = fopen(fn, "a+"); 
    fwrite("\n", sizeof(char), 1, fp); 
    fp = fopen(fn, "a+"); fwrite("\n", sizeof(char), 1, fp); fwrite(buffer, sizeof(char), strlen(buffer), fp);
    fclose(fp);
 } 
 else printf("No permission \n"); 
*/

 if (access(fn, O_RDWR)) { fprintf(stderr, "No permission \n"); return -1; }
 else f1 = open(fn, O_RDWR);
 if (access(fn, O_RDWR)) { fprintf(stderr, "No permission \n"); return -1; }
 else f2 = open(fn, O_RDWR);
 if (access(fn, O_RDWR)) { fprintf(stderr, "No permission \n"); return -1; }
 else f3 = open(fn, O_RDWR);
 if (access(fn, O_RDWR)) { fprintf(stderr, "No permission \n"); return -1; }
 else f4 = open(fn, O_RDWR);

 // Checking i-nodes
 fstat(f1, &stat1);
 fstat(f2, &stat2);
 fstat(f3, &stat3);
 fstat(f4, &stat4);

 // Proof
 if(stat1.st_ino == stat2.st_ino && stat2.st_ino == stat3.st_ino && stat3.st_ino == stat4.st_ino) {
    /* simulating delay */ 
    /*for (i = 0; i < DELAY; i++) {
        int a = i^2; 
    } */

    fp = fopen(fn, "a+"); 
    fwrite("\n", sizeof(char), 1, fp); 
    fp = fopen(fn, "a+"); fwrite("\n", sizeof(char), 1, fp); fwrite(buffer, sizeof(char), strlen(buffer), fp);
    fclose(fp);
 }
 else printf("No permission \n"); 
}




